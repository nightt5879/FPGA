/**
Deng's FOC M0 FOC电流控制例程 适用于SimpleFOC Studio 测试库：SimpleFOC 2.2.1 测试硬件：DengFOC-V4
在串口窗口中输入：M+电流，就可以使得M0电机闭环转动，电流单位为A
setup()中可取消注释设置电压限制与电流限制
在使用自己的电机时，请一定记得修改默认极对数，即 BLDCMotor(7) 中的值，设置为自己的极对数数字
程序默认设置的供电电压为 16.8V,用其他电压供电请记得修改 voltage_power_supply , voltage_limit 变量中的值
默认PID针对的电机是 2208 ，使用自己的电机需要修改PID参数，才能实现更好效果
*/

#include <SimpleFOC.h>

// BLDC motor & driver instance
BLDCMotor motor = BLDCMotor(7);
BLDCDriver3PWM driver = BLDCDriver3PWM(32,33,25,12);

// encoder instance
MagneticSensorI2C sensor = MagneticSensorI2C(AS5600_I2C);
TwoWire I2Cone = TwoWire(0);


// inline current sensor instance
// check if your board has R010 (0.01 ohm resistor) or R006 (0.006 mOhm resistor)
InlineCurrentSense current_sense = InlineCurrentSense(0.01, 50.0, 39, 36);


float adjust_input= 0;
// commander communication instance
Commander command = Commander(Serial);
void doMotor(char* cmd){ command.motor(&motor, cmd); }
void doTarget(char* cmd) { command.scalar(&adjust_input, cmd); }

//I2C初始化
void I2C_init();

void setup() {
  I2C_init();
  // driver config
  // power supply voltage [V]
  driver.voltage_power_supply = 16.8;
  driver.init();
  // link driver
  motor.linkDriver(&driver);

    // 电流限制
  motor.current_limit = 5;

  // TorqueControlType::foc_current
  // 其他模式 TorqueControlType::voltage TorqueControlType::dc_current 
  motor.torque_controller = TorqueControlType::foc_current; 
  // set control loop type to be used
  motor.controller = MotionControlType::torque;

  // contoller configuration based on the controll type 
  motor.PID_velocity.P = 0.021;
  motor.PID_velocity.I = 0.12;
  motor.PID_velocity.D = 0;
  // default voltage_power_supply
  motor.voltage_limit = 16.8;
  motor.voltage_sensor_align = 16.8;  //校准电压
  // velocity low pass filtering time constant
  motor.LPF_velocity.Tf = 0.01;

  // angle loop controller
  motor.P_angle.P = 20;
  // angle loop velocity limit
  motor.velocity_limit = 100;

  // use monitoring with serial for motor init
  // monitoring port
  Serial.begin(115200);
  // comment out if not needed
  motor.useMonitoring(Serial);
  motor.monitor_downsample = 0; // disable intially
  motor.monitor_variables = _MON_TARGET | _MON_VEL | _MON_ANGLE; // monitor target velocity and angle
  
  // current sense init and linking
  current_sense.init();
  // current_sense.gain_b *= 1;
  // current_sense.gain_a *= 1;
  motor.linkCurrentSense(&current_sense);

  // initialise motor
  motor.init();
  // align encoder and start FOC
  motor.initFOC(); 

  // set the inital target value
  motor.target = 0;

  // subscribe motor to the commander
  command.add('M', doMotor, "motor");
  command.add('T', doTarget, "Adjust_input");
  // Run user commands to configure and the motor (find the full command list in docs.simplefoc.com)  
  Serial.println(F("Motor commands sketch | Initial motion control > torque/voltage : target 2V."));
  
  _delay(1000);
}

float init_angle=1.98;  //设定初始角度0度位置
float L=120;       //杆长，单位m
float mass=137;    //重物质量，单位kg
float Kp=0.00001*1;             //修正系数
float target_torque=0;

void loop() {
  // iterative setting FOC phase voltage
  motor.loopFOC();
  target_torque=Kp*adjust_input*L*mass*cos(-(sensor.getAngle()-init_angle));
  // Serial.println(target_torque);
  
  // iterative function setting the outter loop target
  motor.move(-target_torque);

  // motor monitoring
  motor.monitor();

  // user communication
  command.run();
}



void I2C_init(){
  pinMode(32, INPUT_PULLUP);
  pinMode(33, INPUT_PULLUP);
  pinMode(25, INPUT_PULLUP);

  I2Cone.begin(19, 18, 400000UL); // AS5600_M0

  sensor.init(&I2Cone);
  motor.linkSensor(&sensor);
}